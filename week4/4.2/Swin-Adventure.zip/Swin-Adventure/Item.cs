﻿using Swin_Adventure;
using System;

namespace SwinAdventure
{
    public class Item : Game_Object
    {
        public Item(string[] idents, string name, string desc) : base(idents, name, desc)
        {
        }
    }
}